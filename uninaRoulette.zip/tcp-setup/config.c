#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <sys/types.h>
#include <netdb.h>
#include <netinet/in.h>
#include <unistd.h>
#include <stdbool.h>
#include <arpa/inet.h>
#include "config.h"




int connectionConfiguration(struct sockaddr_in *addr, bool type,const char *PORTA, const char *IP){
    
    int sockfd = socket(AF_INET, SOCK_STREAM, 0);
    assert(sockfd != -1);

    bzero(addr, sizeof((*addr)));

    // ASSEGNA IP, PORTA
    (*addr).sin_family = AF_INET;
    (*addr).sin_port = htons(atoi(PORTA));

    if(type) // vero => server address
        (*addr).sin_addr.s_addr = htonl(INADDR_ANY);
    else    // falso => client address
        (*addr).sin_addr.s_addr = inet_addr(IP);

    return sockfd;
}
