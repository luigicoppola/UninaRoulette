#ifndef config_h
#define config_h


int connectionConfiguration(struct sockaddr_in *addr, bool type,const char *PORTA, const char *IP);



#endif
