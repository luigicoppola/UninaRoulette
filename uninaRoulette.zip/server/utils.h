#ifndef utils_h
#define utils_h

#include <stdio.h>
#include "../list/list.h"


void scorePlayers(List bettors, int res, int idGame);
Player linkBidsOnPlayer(Player pippo,List players);




#endif /* utils_h */
